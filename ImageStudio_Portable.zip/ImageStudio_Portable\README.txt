Image Studio - Portable Version 
 
This is a portable version of Image Studio that includes all necessary 
Qt libraries and dependencies. 
 
To run: 
1. Double-click ImageStudio.bat 
2. Or run bin\ImageStudio.exe directly 
 
Features: 
- All image processing filters 
- Drag and drop image loading 
- Undo/Redo functionality 
- Responsive UI 
- Professional interface 
 
No installation required 
